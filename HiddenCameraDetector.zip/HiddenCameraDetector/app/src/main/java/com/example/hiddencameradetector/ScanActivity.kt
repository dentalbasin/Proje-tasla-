package com.example.hiddencameradetector

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.Camera
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.hiddencameradetector.databinding.ActivityScanBinding

class ScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityScanBinding
    private lateinit var camera: Camera
    private val CAMERA_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_REQUEST_CODE)
        } else {
            setupCamera()
        }

        binding.startScanButton.setOnClickListener {
            startScan()
        }
    }

    private fun setupCamera() {
        camera = Camera.open()
        val params = camera.parameters
        params.flashMode = Camera.Parameters.FLASH_MODE_TORCH
        params.previewFormat = ImageFormat.NV21
        camera.parameters = params
    }

    private fun startScan() {
        binding.progressBar.visibility = View.VISIBLE
        binding.startScanButton.visibility = View.GONE

        camera.setPreviewCallback { data, _ ->
            val irDetected = detectIrLight(data)
            binding.progressBar.visibility = View.GONE
            binding.scanResultText.visibility = View.VISIBLE
            binding.scanResultText.text = if (irDetected) {
                "Gizli kamera tespit edildi! Detaylı inceleme yapın."
            } else {
                "Herhangi bir gizli kamera cihazı tespit edilmedi. Güvendesiniz!"
            }
            camera.stopPreview()
            camera.setPreviewCallback(null)
        }
        camera.startPreview()
    }

    private fun detectIrLight(data: ByteArray): Boolean {
        // Basit bir kızılötesi ışık tespit fonksiyonu
        return false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupCamera()
            } else {
                // İzin verilmedi
            }
        }
    }
}
